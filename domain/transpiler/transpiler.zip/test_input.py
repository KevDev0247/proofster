event_input = {
  "body": "{\"formula_infix\": \"FORALL x EXIST y ( ( FORM F y AND FORM G y ) OR ( FORM F x -> FORM G x ) )\"}"
}